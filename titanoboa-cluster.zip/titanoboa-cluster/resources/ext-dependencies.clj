;;NOTE: this is a sample used for demonstration and testing purposes
{:coordinates [[nil]]
 :require [[nil]]
 :import [[nil]]
 :repositories {"central" "https://repo1.maven.org/maven2/"
                "clojars" "https://clojars.org/repo"}}