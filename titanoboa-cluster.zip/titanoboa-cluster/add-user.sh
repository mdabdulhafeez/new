#!/bin/bash
java -cp "./build/titanoboa.jar:./lib/*" titanoboa.server add-user $@