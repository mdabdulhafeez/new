#!/bin/bash 
nohup sudo java -cp "./build/titanoboa.jar:./lib/*" titanoboa.server &
